"use client";

import { useMemo, useState } from "react";
import { CheckCircle2, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import {
  enabledRecognitionTypes,
  recognitionStandards,
} from "@/lib/data";
import type { Employee } from "@/lib/types";

export function PassportEntryForm({ employee }: { employee: Employee }) {
  const [selected, setSelected] = useState<string[]>([
    "lobby_excellence",
    "guest_compliment",
  ]);
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const selectedTypes = enabledRecognitionTypes.filter((type) =>
    selected.includes(type.id),
  );
  const totalMiles = selectedTypes.reduce((total, type) => total + type.milesValue, 0);

  const grouped = useMemo(
    () =>
      recognitionStandards.map((standard) => ({
        standard,
        items: enabledRecognitionTypes.filter((type) => type.standardId === standard.id),
      })),
    [],
  );

  if (submitted) {
    return (
      <div className="rounded-lg border border-journey-red bg-journey-white p-6 shadow-line">
        <CheckCircle2 className="h-10 w-10 text-journey-red" aria-hidden="true" />
        <h2 className="mt-4 text-3xl font-black text-journey-black">
          Journey Card Batch Submitted
        </h2>
        <p className="mt-3 text-lg font-bold text-journey-steel">
          {employee.name} earned {totalMiles} Miles from {selected.length} verified
          Journey Card items.
        </p>
        <p className="mt-4 text-sm font-bold text-journey-steel">
          Batch preview: card-{employee.passportId.toLowerCase()}-today
        </p>
      </div>
    );
  }

  return (
    <form
      className="pb-24"
      onSubmit={(event) => {
        event.preventDefault();
        setSubmitted(true);
      }}
    >
      <div className="grid gap-5">
        {grouped.map(({ standard, items }) => (
          <section key={standard.id} className="rounded-lg border border-journey-line bg-journey-white p-4 shadow-line">
            <div className="mb-4">
              <p className="text-xs font-black uppercase text-journey-red">
                {standard.shortLabel}
              </p>
              <h3 className="text-xl font-black text-journey-black">{standard.label}</h3>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              {items.map((item) => {
                const checked = selected.includes(item.id);
                return (
                  <label
                    key={item.id}
                    className={`flex cursor-pointer items-start gap-3 rounded-lg border p-4 transition ${
                      checked
                        ? "border-journey-red bg-journey-mist"
                        : "border-journey-line bg-journey-white"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(event) =>
                        setSelected((current) =>
                          event.target.checked
                            ? [...current, item.id]
                            : current.filter((id) => id !== item.id),
                        )
                      }
                      className="mt-1 h-6 w-6 accent-journey-red"
                    />
                    <span>
                      <span className="block text-base font-black text-journey-black">
                        {item.name}
                      </span>
                      <span className="mt-1 block text-sm leading-6 text-journey-steel">
                        {item.description}
                      </span>
                      <span className="mt-2 block text-sm font-black text-journey-red">
                        +{item.milesValue} Miles
                      </span>
                    </span>
                  </label>
                );
              })}
            </div>
          </section>
        ))}
      </div>

      <label className="mt-5 grid gap-2 text-sm font-bold text-journey-black">
        Optional Manager Note
        <textarea
          value={note}
          onChange={(event) => setNote(event.target.value)}
          rows={4}
          className="focus-ring resize-none rounded-md border border-journey-line px-3 py-3"
          placeholder="Anything to remember about this Journey Card?"
        />
      </label>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-journey-line bg-journey-white/95 p-4 shadow-premium">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-black uppercase text-journey-red">Batch total</p>
            <p className="text-2xl font-black text-journey-black">
              {totalMiles} Miles from {selected.length} items
            </p>
          </div>
          <Button type="submit" icon={Send}>
            Submit Journey Card Batch
          </Button>
        </div>
      </div>
    </form>
  );
}
